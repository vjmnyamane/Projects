SELECT distinct(ItemType), NameofItem,ItemPrice,Quantity 
FROM datavaultitems.cooldrink
where ItemType = 'Cooldrink'
order by NameofItem;