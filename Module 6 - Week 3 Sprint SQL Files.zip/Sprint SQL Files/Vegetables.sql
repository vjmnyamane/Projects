SELECT distinct(ItemType), NameofItem,ItemPrice,Quantity 
FROM datavaultitems.vegetables
where ItemType = 'vegetable'
order by NameofItem;