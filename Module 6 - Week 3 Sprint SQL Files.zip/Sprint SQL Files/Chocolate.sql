SELECT distinct(ItemType), NameofItem,ItemPrice,Quantity 
FROM datavaultitems.chocolate
where ItemType = 'chocolate'
order by NameofItem;