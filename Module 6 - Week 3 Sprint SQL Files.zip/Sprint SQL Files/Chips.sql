SELECT distinct(ItemType), NameofItem,ItemPrice,Quantity 
FROM datavaultitems.chips
where ItemType = 'Chips'
order by NameofItem;