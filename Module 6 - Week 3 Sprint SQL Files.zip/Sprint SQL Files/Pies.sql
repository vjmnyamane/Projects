SELECT distinct(ItemType), NameofItem,ItemPrice,Quantity 
FROM datavaultitems.pies
where ItemType = 'Pie'
order by NameofItem;