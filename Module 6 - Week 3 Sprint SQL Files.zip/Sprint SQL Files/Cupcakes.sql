SELECT distinct(ItemType), NameofItem,ItemPrice,Quantity 
FROM datavaultitems.cupcakes
where ItemType = 'cupcake'
order by NameofItem;